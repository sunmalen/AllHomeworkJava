Build: mvn clean install
Run: mvn package cargo:run

Open browser: http://localhost:8080